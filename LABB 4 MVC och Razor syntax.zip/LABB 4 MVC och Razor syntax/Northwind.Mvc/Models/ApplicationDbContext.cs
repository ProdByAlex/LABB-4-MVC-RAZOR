﻿using Microsoft.EntityFrameworkCore;

namespace Northwind.Mvc.Models
{
    public class ApplicationDbContext : DbContext
    {
        public DbSet<Category> Categories { get; set; }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder); 

            modelBuilder.Entity<Category>().HasData(
                new Category { CategoryId = 1, CategoryName = "Beverages", Description = "Soft drinks, coffee, tea" },
                new Category { CategoryId = 2, CategoryName = "Condiments", Description = "Sauces, spices, seasonings" },
                new Category { CategoryId = 3, CategoryName = "Confections", Description = "Desserts, candies, sweet breads" },
                new Category { CategoryId = 4, CategoryName = "Dairy Products", Description = "Cheeses" },
                new Category { CategoryId = 5, CategoryName = "Grains/Cereals", Description = "Breads, crackers, pasta" },
                new Category { CategoryId = 6, CategoryName = "Meat/Poultry", Description = "Prepared meats" },
                new Category { CategoryId = 7, CategoryName = "Produce", Description = "Dried fruit and bean curd" },
                new Category { CategoryId = 8, CategoryName = "Seafood", Description = "Seaweed and fish" }
            );
        }
    }
}
